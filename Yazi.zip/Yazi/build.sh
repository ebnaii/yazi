sh /home/build/aports/scripts/mkimage.sh --tag edge \
	--outdir ~/iso \
	--arch x86_64 \
	--repository https://dl-cdn.alpinelinux.org/alpine/edge/main \
	--extra-repository https://dl-cdn.alpinelinux.org/alpine/edge/community \
	--profile yazi